# ClawAgent — Browser Operator (Chrome extension)

Your ClawAgent AI drives your **real** browser — it clicks, types, scrolls and
navigates on the page **you're already on**, while you watch. There's always a
**Stop** button. This is real browser control (not a demo).

## What it can do
- Do web tasks on sites you're **already logged into** (search, open results,
  fill a form, click through a flow) — like a human assistant sitting at your PC.
- Works on the current tab. Multi-page tasks survive navigation.

## What it will NOT do (on purpose)
- It never types passwords, OTP/2FA codes, or card/credential details.
- It never solves CAPTCHAs / "I'm not a robot" checks.
- If a task needs a login, payment, or captcha, it stops and asks **you** to do it.
- It only runs while you're there, and you can Stop anytime.

> Note: Facebook / Google / WhatsApp actively block automation. Use this as a
> co-pilot with you present. For hands-off, 24×7 sending, use the official APIs
> in ClawAgent → **🔌 Connections** (WhatsApp / Facebook / Telegram).

## Install (takes 1 minute)
1. Unzip this folder somewhere permanent.
2. Open Chrome → go to `chrome://extensions`
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** → select this unzipped folder.
5. Pin the **ClawAgent — Browser Operator** icon (puzzle-piece menu → pin).

## Use
1. Open a normal website (e.g. `google.com`). (It can't run on `chrome://` pages.)
2. Click the ClawAgent icon.
3. Type a command, e.g. *"'best cafe in jaipur' search karo aur pehla result kholo"*.
4. Press **Start** — watch the green panel; press **Stop** anytime.

## Settings
The extension talks to your ClawAgent site's brain at
`https://clawagent-sigma.vercel.app/api/agent/plan` (uses your server's
`ANTHROPIC_API_KEY`). Change the endpoint in the popup's ⚙️ Settings if you host
ClawAgent elsewhere.
