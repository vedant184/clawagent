/* ClawAgent Browser Operator — background service worker.
 * Owns the single active "run" and relays messages. Survives page navigations
 * by re-triggering the content script's loop after each page finishes loading. */

const KEY = "claw_run";

function getRun() {
  return new Promise((res) => chrome.storage.local.get(KEY, (o) => res(o[KEY] || null)));
}
function setRun(run) {
  return new Promise((res) => chrome.storage.local.set({ [KEY]: run }, res));
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

// The brain call MUST happen here in the background, not in the content script.
// A content script's fetch runs in the page and is blocked by many sites'
// Content-Security-Policy (connect-src) — e.g. Google, Facebook, GitHub. The
// background service worker has host_permissions and is not subject to page CSP
// or CORS, so it can always reach the endpoint.
async function callBrain(endpoint, payload) {
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

// Make sure the content script is actually present in the tab. Content scripts
// declared in the manifest do NOT auto-inject into tabs that were already open
// before the extension was loaded — so we inject on demand here. The content
// script guards against double-injection, so calling this is always safe.
async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return true;
  } catch (e) {
    return false;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  // A freshly-loaded content script announces itself; tell it whether to resume.
  if (msg.type === "CLAW_HELLO") {
    getRun().then((run) => {
      const active = !!(run && run.running && sender.tab && sender.tab.id === run.tabId);
      sendResponse({ resume: active, run: active ? run : null });
    });
    return true;
  }

  // Popup pressed Start.
  if (msg.type === "CLAW_START") {
    const run = {
      running: true,
      goal: msg.goal,
      endpoint: msg.endpoint,
      tabId: msg.tabId,
      step: 0,
      history: [],
      startedAt: Date.now(),
    };
    (async () => {
      const injected = await ensureContentScript(msg.tabId);
      if (!injected) {
        sendResponse({ ok: false, error: "Is page pe extension chal nahi sakta (shayad chrome:// ya store page hai). Kisi normal website pe kholo." });
        return;
      }
      await setRun(run);
      await wait(200); // let the content script register its listener
      try {
        await chrome.tabs.sendMessage(msg.tabId, { type: "CLAW_BEGIN", run });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: "Content script tak message nahi pahuncha — page reload karke phir try karo." });
      }
    })();
    return true;
  }

  // Stop from popup or the on-page panel.
  if (msg.type === "CLAW_STOP") {
    getRun().then((run) => {
      if (run) {
        run.running = false;
        setRun(run).then(() => {
          if (run.tabId) chrome.tabs.sendMessage(run.tabId, { type: "CLAW_HALT" }).catch(() => {});
          sendResponse({ ok: true });
        });
      } else sendResponse({ ok: true });
    });
    return true;
  }

  // Content script persists updated step/history so a navigation can resume cleanly.
  if (msg.type === "CLAW_SAVE") {
    getRun().then((run) => {
      if (run) {
        run.step = msg.step ?? run.step;
        run.history = msg.history ?? run.history;
        if (msg.done) run.running = false;
        setRun(run).then(() => sendResponse({ ok: true }));
      } else sendResponse({ ok: false });
    });
    return true;
  }

  // Content script asks the background to fetch the next plan (bypasses page CSP).
  if (msg.type === "CLAW_PLAN") {
    callBrain(msg.endpoint, msg.payload)
      .then(({ status, ok, data }) => {
        if (ok && data && Array.isArray(data.actions)) sendResponse({ ok: true, plan: data });
        else sendResponse({ ok: false, error: (data && data.error) || `HTTP ${status}` });
      })
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  // Popup's "Test connection" — same path Start uses, so the result is trustworthy.
  if (msg.type === "CLAW_TEST") {
    callBrain(msg.endpoint, {
      goal: "connection test",
      url: "https://example.com",
      title: "test",
      elements: [{ id: 0, tag: "a", text: "test link" }],
      history: [],
    })
      .then(({ status, ok, data }) =>
        sendResponse({ ok, status, hasPlan: !!(data && Array.isArray(data.actions)), error: data && data.error }))
      .catch((e) => sendResponse({ ok: false, netError: String((e && e.message) || e) }));
    return true;
  }

  // Relay progress lines to the popup if it happens to be open.
  if (msg.type === "CLAW_PROGRESS") {
    chrome.runtime.sendMessage({ type: "CLAW_LOG", entry: msg.entry }).catch(() => {});
    return;
  }
});

// After any page finishes loading, if a run is active on that tab, make sure the
// content script is there and resume the loop (handles the agent navigating).
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== "complete") return;
  getRun().then(async (run) => {
    if (run && run.running && run.tabId === tabId) {
      await ensureContentScript(tabId);
      await wait(150);
      chrome.tabs.sendMessage(tabId, { type: "CLAW_RESUME", run }).catch(() => {});
    }
  });
});
