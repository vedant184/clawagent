/* ClawAgent Browser Operator — content script (runs in the page).
 * Extracts interactive elements, asks the ClawAgent brain for the next action,
 * and performs it like a human would — with a visible panel + Stop button.
 * Survives navigation: state lives in the background run; each new page resumes. */

(() => {
  if (window.__clawInjected) return;
  window.__clawInjected = true;

  const MAX_STEPS = 30;
  let running = false;
  let goal = "";
  let endpoint = "";
  let step = 0;
  let history = [];
  let busy = false;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const send = (m) => { try { chrome.runtime.sendMessage(m); } catch (e) {} };
  const log = (line) => { send({ type: "CLAW_PROGRESS", entry: line }); setPanel(line); };

  /* ---------- sensitive-field guard (second layer; the server also refuses) ---------- */
  function isSensitive(el, type) {
    const t = (type || "").toLowerCase();
    if (["password", "email", "tel"].includes(t) && t === "password") return true;
    if (t === "password") return true;
    const hay = ((el.getAttribute("name") || "") + " " + (el.getAttribute("id") || "") + " " +
      (el.getAttribute("autocomplete") || "") + " " + (el.getAttribute("aria-label") || "")).toLowerCase();
    return /pass|otp|one-?time|cvv|cvc|card-?number|cardnumber|creditcard|ssn|security-?code/.test(hay);
  }

  /* ---------- collect visible interactive elements ---------- */
  function collect() {
    const sel = "a,button,input,textarea,select,[role=button],[role=link],[role=textbox],[role=searchbox],[contenteditable=true],[onclick]";
    const nodes = Array.from(document.querySelectorAll(sel));
    const out = [];
    let id = 0;
    for (const el of nodes) {
      let r;
      try { r = el.getBoundingClientRect(); } catch { continue; }
      const cs = getComputedStyle(el);
      const visible = r.width > 2 && r.height > 2 && cs.visibility !== "hidden" &&
        cs.display !== "none" && Number(cs.opacity) > 0.05 &&
        r.bottom > -300 && r.top < (window.innerHeight + 600);
      if (!visible) continue;
      const tag = el.tagName.toLowerCase();
      const type = el.getAttribute("type") || undefined;
      const label = (el.getAttribute("aria-label") || el.getAttribute("placeholder") ||
        el.innerText || el.value || el.getAttribute("name") || el.getAttribute("title") || "")
        .toString().trim().replace(/\s+/g, " ").slice(0, 120);
      el.setAttribute("data-claw-id", String(id));
      out.push({
        id, tag, type,
        role: el.getAttribute("role") || undefined,
        name: el.getAttribute("name") || undefined,
        text: label,
        sensitive: isSensitive(el, type) || undefined,
      });
      id++;
    }
    return out;
  }

  function byId(id) { return document.querySelector(`[data-claw-id="${id}"]`); }

  /* ---------- human-like helpers ---------- */
  function highlight(el) {
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
    const prev = el.style.outline;
    el.style.outline = "3px solid #34d399";
    el.style.outlineOffset = "2px";
    moveCursorTo(el);
    setTimeout(() => { el.style.outline = prev; }, 900);
  }
  function nativeSetValue(el, val) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value") && Object.getOwnPropertyDescriptor(proto, "value").set;
    if (setter) setter.call(el, val); else el.value = val;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function pressEnter(el) {
    ["keydown", "keypress", "keyup"].forEach((t) =>
      el.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true })));
    if (el.form && typeof el.form.requestSubmit === "function") { try { el.form.requestSubmit(); } catch (e) {} }
  }

  /* ---------- fake cursor for visual feedback ---------- */
  let cursorEl = null;
  function ensureCursor() {
    if (cursorEl) return cursorEl;
    cursorEl = document.createElement("div");
    cursorEl.textContent = "🖱️";
    Object.assign(cursorEl.style, {
      position: "fixed", zIndex: 2147483647, fontSize: "22px", left: "50%", top: "50%",
      transition: "left .5s ease, top .5s ease", pointerEvents: "none", filter: "drop-shadow(0 2px 4px rgba(0,0,0,.5))",
    });
    document.documentElement.appendChild(cursorEl);
    return cursorEl;
  }
  function moveCursorTo(el) {
    const c = ensureCursor();
    const r = el.getBoundingClientRect();
    c.style.left = (r.left + r.width / 2) + "px";
    c.style.top = (r.top + r.height / 2) + "px";
  }

  /* ---------- floating panel with Stop ---------- */
  let panel = null, panelMsg = null;
  function ensurePanel() {
    if (panel) return;
    panel = document.createElement("div");
    Object.assign(panel.style, {
      position: "fixed", right: "16px", bottom: "16px", zIndex: 2147483647, width: "300px",
      background: "#0a1815", color: "#d1fae5", border: "1px solid #34d39955", borderRadius: "14px",
      boxShadow: "0 10px 40px rgba(0,0,0,.5)", padding: "12px 14px", fontFamily: "system-ui,sans-serif",
      fontSize: "13px", lineHeight: "1.4",
    });
    panel.innerHTML =
      '<div style="display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:6px">' +
      '<span style="width:8px;height:8px;border-radius:50%;background:#34d399;display:inline-block;box-shadow:0 0 0 0 #34d39980;animation:clawpulse 1.4s infinite"></span>' +
      'ClawAgent is working…</div>' +
      '<div id="claw-msg" style="color:#a7f3d0cc;min-height:32px;margin-bottom:8px">Ready.</div>' +
      '<div style="display:flex;gap:8px"><button id="claw-stop" style="flex:1;background:#e11d48;color:#fff;border:0;border-radius:8px;padding:7px 10px;font-weight:600;cursor:pointer">■ Stop</button></div>' +
      '<div style="margin-top:6px;font-size:10px;color:#6ee7b799">Aap kabhi bhi Stop daba sakte ho.</div>';
    const style = document.createElement("style");
    style.textContent = "@keyframes clawpulse{0%{box-shadow:0 0 0 0 #34d39980}70%{box-shadow:0 0 0 8px #34d39900}100%{box-shadow:0 0 0 0 #34d39900}}";
    document.documentElement.appendChild(style);
    document.documentElement.appendChild(panel);
    panelMsg = panel.querySelector("#claw-msg");
    panel.querySelector("#claw-stop").addEventListener("click", stopRun);
  }
  function setPanel(text) { ensurePanel(); if (panelMsg) panelMsg.textContent = text; }
  function removePanel() { if (panel) { panel.remove(); panel = null; } if (cursorEl) { cursorEl.remove(); cursorEl = null; } }

  /* ---------- execute one action ---------- */
  async function execute(a) {
    if (a.type === "click") {
      const el = byId(a.id); if (!el) return { note: "element gaya", nav: false };
      highlight(el); await sleep(500);
      const willNav = el.tagName === "A" && el.href && !el.href.startsWith("javascript");
      try { el.click(); } catch (e) {}
      return { note: `clicked: ${(el.innerText || el.value || a.id).toString().slice(0, 40)}`, nav: willNav };
    }
    if (a.type === "type") {
      const el = byId(a.id); if (!el) return { note: "field gaya", nav: false };
      if (isSensitive(el, el.getAttribute("type"))) return { note: "sensitive field — skipped (safety)", nav: false };
      highlight(el); el.focus(); await sleep(300);
      if (el.isContentEditable) { el.textContent = a.text; el.dispatchEvent(new Event("input", { bubbles: true })); }
      else nativeSetValue(el, a.text);
      await sleep(250);
      let nav = false;
      if (a.enter) { pressEnter(el); nav = true; }
      return { note: `typed: ${String(a.text).slice(0, 40)}`, nav };
    }
    if (a.type === "scroll") {
      window.scrollBy({ top: a.direction === "up" ? -600 : 600, behavior: "smooth" });
      await sleep(500); return { note: `scroll ${a.direction}`, nav: false };
    }
    if (a.type === "navigate") {
      setPanel("Opening " + a.url); await sleep(300);
      location.href = a.url; return { note: "navigate " + a.url, nav: true };
    }
    if (a.type === "wait") { await sleep(1200); return { note: "waited", nav: false }; }
    if (a.type === "done") return { note: "done", nav: false, stop: true, done: true };
    if (a.type === "ask") return { note: a.note || "need you", nav: false, stop: true, ask: true };
    return { note: "unknown action", nav: false };
  }

  /* ---------- the loop ---------- */
  async function loop() {
    if (busy) return; busy = true;
    ensurePanel();
    try {
      while (running && step < MAX_STEPS) {
        const elements = collect();
        // Ask the BACKGROUND to call the brain — a content-script fetch would be
        // blocked by many sites' CSP (Google/Facebook/etc.). Background is not.
        let plan;
        try {
          const resp = await chrome.runtime.sendMessage({
            type: "CLAW_PLAN",
            endpoint,
            payload: { goal, url: location.href, title: document.title, elements, history, step },
          });
          if (!resp || !resp.ok) {
            log("Server: " + ((resp && resp.error) || "koi jawab nahi") + ". '🔌 Test connection' dabao.");
            running = false; break;
          }
          plan = resp.plan;
        } catch (e) {
          log("Background se plan nahi mila: " + ((e && e.message) || e));
          running = false; break;
        }
        if (plan.thought) setPanel(plan.thought);
        const actions = Array.isArray(plan.actions) ? plan.actions : [];
        let navigated = false, finished = false;
        for (const a of actions) {
          if (!running) break;
          const r = await execute(a);
          history.push({ action: a.type, target: a.id != null ? String(a.id) : (a.url || a.direction || ""), result: r.note });
          if (history.length > 20) history = history.slice(-20);
          log((a.note || a.type) + " — " + r.note);
          if (r.ask) { setPanel("🙋 " + r.note); finished = true; running = false; break; }
          if (r.done) { setPanel("✅ Ho gaya!"); finished = true; running = false; break; }
          if (r.nav) { navigated = true; break; }
          await sleep(650);
        }
        step++;
        // persist so a navigation can resume
        send({ type: "CLAW_SAVE", step, history, done: finished || plan.done === true });
        if (navigated) { busy = false; return; } // content script will reload + resume
        if (finished || plan.done === true) { running = false; break; }
        await sleep(500);
      }
      if (step >= MAX_STEPS && running) setPanel("Step limit aa gaya — ruk raha hoon.");
      if (!running) { /* stopped or done */ }
    } finally {
      busy = false;
    }
  }

  function startFromRun(run) {
    goal = run.goal; endpoint = run.endpoint; step = run.step || 0;
    history = Array.isArray(run.history) ? run.history : [];
    running = true;
    loop();
  }
  function stopRun() {
    running = false;
    setPanel("⏹ Ruk gaya. (Aapne Stop dabaya)");
    send({ type: "CLAW_STOP" });
    setTimeout(removePanel, 2500);
  }

  /* ---------- messaging ---------- */
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || !msg.type) return;
    if (msg.type === "CLAW_BEGIN") startFromRun(msg.run);
    else if (msg.type === "CLAW_RESUME") { if (!running && !busy) startFromRun(msg.run); }
    else if (msg.type === "CLAW_HALT") { running = false; setPanel("⏹ Ruk gaya."); setTimeout(removePanel, 2000); }
  });

  // On load, ask background whether a run is active for this tab (resume after nav).
  try {
    chrome.runtime.sendMessage({ type: "CLAW_HELLO" }, (resp) => {
      if (chrome.runtime.lastError) return;
      if (resp && resp.resume && resp.run) startFromRun(resp.run);
    });
  } catch (e) {}
})();
