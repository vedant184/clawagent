/* ClawAgent Operator — popup UI */
const DEFAULT_ENDPOINT = "https://clawagent-sigma.vercel.app/api/agent/plan";

const $ = (id) => document.getElementById(id);
const logEl = $("log");
function addLog(line) {
  const t = new Date().toLocaleTimeString();
  logEl.textContent = `[${t}] ${line}\n` + logEl.textContent;
}

// show version so we can confirm the right build is loaded
try { $("ver").textContent = "v" + chrome.runtime.getManifest().version; } catch (e) {}

// shared connection test (used by the button AND auto-run on open)
async function testConnection(silent) {
  const endpoint = ($("endpoint").value.trim() || DEFAULT_ENDPOINT);
  if (!silent) addLog("🔌 Server test kar raha hoon…");
  try {
    const r = await chrome.runtime.sendMessage({ type: "CLAW_TEST", endpoint });
    if (!r) { addLog("❌ Background se jawab nahi — extension Reload karo (chrome://extensions)."); return; }
    if (r.ok && r.hasPlan) addLog("✅ Server ready! Ab command likho aur Start dabao.");
    else if (r.error && /ANTHROPIC_API_KEY/.test(r.error)) addLog("❌ Server mila, par ANTHROPIC_API_KEY set nahi hai (Vercel env vars).");
    else if (r.error) addLog("⚠️ Server bola: " + r.error);
    else if (r.netError) addLog("❌ Server tak nahi pahuncha: " + r.netError);
    else addLog("⚠️ Server ne HTTP " + (r.status || "?") + " diya. Endpoint check karo (Settings).");
  } catch (e) {
    addLog("❌ Test fail: " + ((e && e.message) || e));
  }
}

// restore saved endpoint + last goal
chrome.storage.local.get(["claw_endpoint", "claw_lastgoal"], (o) => {
  $("endpoint").value = o.claw_endpoint || DEFAULT_ENDPOINT;
  if (o.claw_lastgoal) $("goal").value = o.claw_lastgoal;
});

// show which page Start will run on (helps catch "wrong tab / chrome:// page"),
// then auto-test the server so the very first thing the user sees is the truth.
chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  const u = (tab && tab.url) || "";
  if (/^(chrome|edge|about|chrome-extension|devtools|view-source):/i.test(u)) {
    addLog("⚠️ Abhi aap ek internal page pe ho. Kisi normal website (jaise google.com) pe jao, phir Start.");
  } else if (u) {
    try { addLog("Ready on: " + new URL(u).hostname); } catch { addLog("Ready."); }
  }
  testConnection(true); // auto connection check on open
}).catch(() => { testConnection(true); });

// Diagnose exactly where things break: is the brain server reachable + configured?
$("test").addEventListener("click", () => testConnection(false));

$("start").addEventListener("click", async () => {
  try {
    const goal = $("goal").value.trim();
    const endpoint = ($("endpoint").value.trim() || DEFAULT_ENDPOINT);
    if (!goal) { addLog("Pehle command likho, phir Start dabao."); return; }
    chrome.storage.local.set({ claw_endpoint: endpoint, claw_lastgoal: goal });

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) { addLog("Koi active tab nahi mila."); return; }
    if (/^(chrome|edge|about|chrome-extension|devtools|view-source):/i.test(tab.url || "")) {
      addLog("Ye Chrome ka internal page hai. Kisi normal website (jaise google.com) pe jao, phir Start dabao.");
      return;
    }

    addLog("Start: " + goal);
    chrome.runtime.sendMessage({ type: "CLAW_START", goal, endpoint, tabId: tab.id }, (r) => {
      if (chrome.runtime.lastError) {
        addLog("Extension background se baat nahi hui — chrome://extensions pe ja ke extension ko Reload karo.");
        return;
      }
      if (r && r.ok) addLog("✅ Chalu! Page pe green panel dekho — AI kaam kar raha hai.");
      else addLog("⚠️ " + ((r && r.error) || "Start nahi hua. Page reload karke phir try karo."));
    });
  } catch (e) {
    addLog("Error: " + (e && e.message ? e.message : String(e)));
  }
});

$("stop").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "CLAW_STOP" }, () => addLog("⏹ Stop bheja."));
});

// live progress from the content script (relayed by background)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "CLAW_LOG") addLog(msg.entry);
});
